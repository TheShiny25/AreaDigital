$(document).ready(function() {

/*$("#sliderPrincipal").owlCarousel({
      items: 1,
      autoPlay: true,
      navigation: false,
      navigationText : ["",""],
      pagination: true,
      lazyLoad : false,
      autoWidth: false,
      itemsDesktop: [1000, 1], //5 items between 1000px and 901px
      itemsDesktopSmall: [991, 1], // betweem 900px and 601px
      itemsTablet: [768, 1], //2 items between 600 and 0
      itemsMobile: [479, 1]
  });*/

    /*Slider Principal*/
   /* var ancho = $(window).width();
    var res_boli = false;
    var res_flec = true;
    if(ancho < 1000){
      res_boli=true;
      res_flec=false;
    }
    $("#slider-list").owlCarousel({
        items: 4,
        autoPlay: false,
        navigation: res_flec,
        navigationText : ["",""],
          //navigationText: ["<img src='images/flecha-izq.png'>","<img src='images/flecha-der.png'>"],
        pagination: res_boli,
        autoWidth: false,
        itemsDesktop: [1000, 4], //5 items between 1000px and 901px
        itemsDesktopSmall: [991, 3], // betweem 900px and 601px
        itemsTablet: [768, 3], //2 items between 600 and 0
        itemsMobile: [479, 2]
    });*/




});
